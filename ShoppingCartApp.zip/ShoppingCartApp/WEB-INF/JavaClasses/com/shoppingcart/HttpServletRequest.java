package com.shoppingcart;

public class HttpServletRequest {

}
